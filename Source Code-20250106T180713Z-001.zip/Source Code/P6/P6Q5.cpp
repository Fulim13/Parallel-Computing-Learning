// P6Q5.cpp : Defines the entry point for the console application.
// Program that computes the average of an array of elements in parallel using
// MPI_Scatter and MPI_Gather

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <mpi.h>
#include <assert.h>

// Creates an array of random numbers. Each number has a value from 0 - 1
double *create_rand_nums(int num_elements) {
     double *rand_nums = (double *)malloc(sizeof(double) * num_elements);
     assert(rand_nums != NULL);
     int i;
     for (i = 0; i < num_elements; i++) {
          rand_nums[i] = (rand() / (double)RAND_MAX);
     }
     return rand_nums;
}

// Computes the average of an array of numbers
double compute_avg(double *array, int num_elements) {
     double sum = 0.f;
     int i;
     for (i = 0; i < num_elements; i++) {
          sum += array[i];
     }
     return sum / num_elements;
}

int main(int argc, char** argv) {
     if (argc != 2) {
          fprintf(stderr, "Usage: %s num_elements_per_proc\n", argv[0]);
          exit(1);
     }

     int num_elements_per_proc = atoi(argv[1]);
     // Seed the random number generator to get different results each time
     srand((unsigned int)time(NULL));

     MPI_Init(NULL, NULL); 

     // Create "world_rank" and set it to the process ID
     // ...

     // Create "world_size" and set it to number of MPI processes
     // ...

     // Create a random array of elements on the root process. Its total
     // size will be the number of elements per process times the number
     // of processes
     double *rand_nums = NULL;
     if (world_rank == 0) {
          rand_nums = create_rand_nums(num_elements_per_proc * world_size);
     }

     // For each process, create a buffer that will hold a subset of the entire
     // array
     double *sub_rand_nums = (double *)malloc(sizeof(double) * num_elements_per_proc);
     assert(sub_rand_nums != NULL);

     // Scatter the random numbers from the root process to all processes in
     // the MPI world
     // ... <your code to scatter> ...

     // Compute the average of your subset
     double sub_avg = compute_avg(sub_rand_nums, num_elements_per_proc);

     // Gather all partial averages down to the root process
     double *sub_avgs = NULL;
     if (world_rank == 0) {
          sub_avgs = (double *)malloc(sizeof(double) * world_size);
          assert(sub_avgs != NULL);
     }
     // ... <your code to gather> ...

     // Now that we have all of the partial averages on the root, compute the
     // total average of all numbers. Since we are assuming each process computed
     // an average across an equal amount of elements, this computation will
     // produce the correct answer.
     if (world_rank == 0) {
          double avg = compute_avg(sub_avgs, world_size);
          printf("Avg of all elements is %f\n", avg);
          // Compute the average across the original data for comparison
          double original_data_avg =
               compute_avg(rand_nums, num_elements_per_proc * world_size);
          printf("Avg computed across original data is %f\n", original_data_avg);
     }

     // Clean up
     if (world_rank == 0) {
          free(rand_nums);
          free(sub_avgs);
     }
     free(sub_rand_nums);

     MPI_Finalize();
     
     return 0;
}