// P6Q4.cpp : Defines the entry point for the console application.
// To run the program with 4 threads type:
//    mpiexec -n 4 P6Q4.exe
//

#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int p6q4(int argc, char** argv) {
  int rank, value, size;
  MPI_Status status;

  do {
    if (rank == 0) {
        printf("Please give a number: ");
        fflush(stdout);
        scanf_s("%d", &value);

        // Process 0 send the message 

    } else {
        // Receive from the previous rank/process ID

        if (rank < size - 1)
            // All ranks, except the last, send the value to
            // their immediate neighbours
            MPI_Send(&value, 1, MPI_INT, rank + 1, 0, MPI_COMM_WORLD);
    }
    printf("Process %d received %d (error code: %d)\n", rank, value,
                                                        status.MPI_ERROR);
    fflush(stdout);
  } while (value >= 0);

  MPI_Finalize();
  return 0;
}