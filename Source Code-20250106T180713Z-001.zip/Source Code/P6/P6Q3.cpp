// mpiexec -np 4 P6Q3

#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char **argv) {
    int rank, value;
    
    do {
      if (rank == 0) {
        printf("Please give a number (negative number to terminate): ");
        fflush(stdout);       // Force immediate printing
        scanf_s("%d", &value);
      }
      //Broadcast the input value to all the processes
    
      printf("Process %d received %d\n", rank, value);
      fflush(stdout);         // Force immediate printing
      
      // Synchronize the processes (wait for all the
      // processes to print their values before proceeding
      // to ask for the next value.)

    } while (value >= 0);
    
    printf("Process %d terminated.\n", rank);
    
    return 0;
}